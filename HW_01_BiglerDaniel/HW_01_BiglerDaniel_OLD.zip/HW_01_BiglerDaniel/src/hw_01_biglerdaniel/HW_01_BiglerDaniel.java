/*
 * Daniel Bigler
 * 190821
 * input a number of days, output the number of days that can be missed
 */
package hw_01_biglerdaniel;
import javax.swing.JOptionPane;
public class HW_01_BiglerDaniel {
    public static void main(String[] args) {
        String name;
        String courseSection;
        String courseName;
        double hours;
        double missHours;
        double missDays;
        
        name = get_name();
        courseSection = get_courseSection();
        courseName = get_courseName();
        hours = get_hours();
        missHours = twentyPercent(hours);
        missDays = calc_days(missHours);
        
        JOptionPane.showMessageDialog(null, 
                "Hello " + name + '\n' +
                "Course Section: " + courseSection + '\n' +
                "Course Name: " + courseName + '\n' + 
                "Total Class/Lab Hours: " + hours + '\n' +
                "Allowed Absences - Hours: " + missHours + '\n' + 
                "Allowed Absences - Days: " + missDays + '\n' + 
                "=====================================");
    }
    public static String get_name() {
        String name;
        
        // get the person's name
        name = JOptionPane.showInputDialog("What is your name? ");
        return name;
    }
    public static String get_courseSection() {
        String courseSection;
        
        // get the course section. ex: WEB-251
        courseSection = JOptionPane.showInputDialog("What is the course "
                + "section? ");
        return courseSection;
    }
    public static String get_courseName() {
        String courseName;
        
        // get the course name. ex: Mobile Application
        courseName = JOptionPane.showInputDialog("What is the course name? ");
        return courseName;
    }
    
    public static double get_hours() {
        String input;           // input for dialog box
        final int minimum = 1;  // hours within class has to be this or more
        double hours;            // Number of hours
        
        // Get number of hours. ex: 64
        input = JOptionPane.showInputDialog("How many hours are there "
                + "in the class throughout the semester? ");
        hours = Double.parseDouble(input);
        
        // Input validation. Make sure it's a positive number
        while (hours < minimum) {
        input = JOptionPane.showInputDialog("Please enter a number greater "
                + "than zero.");
        hours = Double.parseDouble(input);
        }
        return (double) hours;        
    }
    public static double twentyPercent(Double hours){
        double result;
            
        result = hours * 0.2;
        
        return result;
    }
    public static double calc_days(double missHours){
        double missDays;
        
        //temporary, will be changed
        missDays = missHours/2;
        return missDays;
    }
}

//get name
//get class name
//how many hours in the semester
//  ex: 2 hours x 2 days a week x 16 weeks = 64
//MaTh MaGiC Is DoNe HeRe
//  20%ofTheTotalHours

//  IfADecimalThenRoundUp
//  13hoursWillBeCountedAs7,2hourClasses
//
//20%of64hours
//  12.8hours -> 7days
//32 -> 6.4 -> 4
//28 -> 5.6 -> 3
//16 -> 3.2 -> 2