/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hw_02_biglerdaniel;
public class HW_02_BiglerDaniel {
    public static void main(String[] args) {
        int loops;
        
        // add: input for switch to use
        //      and the three loops
        switch (loops)
        {
            case 1:
                System.out.println("while");
                break;
            case 2:
                System.out.println("do");
                break;
            case 3:
                System.out.println("for");
                break;
            default:
                System.out.println("wrong number, try 1, 2, 3.");
                break;
        }
    }
    
}
